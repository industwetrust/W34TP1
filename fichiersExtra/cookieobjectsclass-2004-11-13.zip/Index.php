<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Cookie Test - CookieObjects Class</title>
<meta http-equiv="imagetoolbar" content="false">
<META NAME="Title" CONTENT="Cookie Test  CookieObjects Class">
<META NAME="Author" CONTENT="Guillermo de Jesus Perez Chavero">
<META NAME="Keywords" CONTENT="Cookie, PHP5, Class">
<META NAME="Language" CONTENT="Espa�ol/English">
<META NAME="Copyright" CONTENT="� Chavero Soft">
<META NAME="Designer" CONTENT="Guillermo de Jesus Perez Chavero">
<META NAME="Publisher" CONTENT="Guillermo de Jesus Perez Chavero">
<META NAME="Robots" CONTENT="Index">
</head>
<frameset cols="400px,*"             frameborder="no" border="1" scrolling="auto" framespacing="0">
<frame src="SendData.php" name="left"          frameborder="no" border="0" scrolling="auto" marginwidth="0" marginheight="0" />
  <frameset rows="50%,*"             frameborder="no" border="1" scrolling="auto" framespacing="0">
    <frame src="GetData.php" name="top_right"     frameborder="no" border="1" scrolling="auto" marginwidth="0" marginheight="0" />
    <frame src="ViewDataI.php" name="bottom_right"  frameborder="no" border="1" scrolling="auto" marginwidth="0" marginheight="0" />
  </frameset>
</frameset>
<noframes>
<?php echo "Hola";?>
 <center><font face="verdana,arial" size="3">Your browser does not support frames!</center></font>
</noframes>
</html>
